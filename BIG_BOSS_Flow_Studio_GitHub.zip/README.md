# BIG_BOSS Flow Studio

A responsive, Google Flow-inspired front-end prototype for writing video prompts and organizing scenes.

## Features
- Mobile-friendly dark creative-studio interface
- Prompt composer with character counter
- Duration, aspect ratio, model-style and visual-style selectors
- Reference image picker
- Scene storyboard saved in browser localStorage
- Export storyboard prompts as a `.txt` file

## Important
This is a **front-end prototype**, not a working AI video generator. The Generate button saves the prompt as a storyboard scene. To render real video, connect a video-generation provider through a secure backend/serverless function. Do not put private API keys in `index.html` or any public GitHub repository.

## Publish with GitHub Pages
1. Create a new GitHub repository, for example `big-boss-flow-studio`.
2. Upload `index.html` and this `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for the Pages deployment. Your site address will look like `https://YOUR-USERNAME.github.io/big-boss-flow-studio/`.

You can also upload the ZIP contents directly from GitHub's web interface.
